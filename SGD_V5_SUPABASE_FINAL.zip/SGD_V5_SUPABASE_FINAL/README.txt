SGD V5 FINAL — LOGIN SUPABASE

Esta versão remove os acessos de demonstração admin/admin123 e usa exclusivamente o login por e-mail e palavra-passe do Supabase.

Project URL: https://edttbjysaqdounpghsdn.supabase.co

Chave: publicável (configurada no index.html)

Para publicar no GitHub/Vercel: substitua o index.html existente por este.
